﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        private static List<Employee> employees = new List<Employee>();

        // 1. Display a list of all employees
        public IActionResult Index()
        {
            return View(employees);
        }

        // 2. Add a new employee to the list
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            if (ModelState.IsValid)
            {
                employee.Id = employees.Count > 0 ? employees.Max(e => e.Id) + 1 : 1;
                employees.Add(employee);
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        // 3. Edit an existing employee
        [HttpGet]
        public IActionResult Edit(int id)
        {
            Employee employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
            {
                return NotFound();
            }
            return View(employee);
        }

        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            if (ModelState.IsValid)
            {
                var emp = employees.FirstOrDefault(e => e.Id == employee.Id);
                if (emp != null)
                {
                    emp.Name = employee.Name;
                    emp.Email = employee.Email;
                    emp.Age = employee.Age;
                }
                return RedirectToAction("Index");
            }
            return View(employee);
        }

        // 4. Delete an employee
        public IActionResult Delete(int id)
        {
            Employee employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
            {
                return NotFound();
            }
            employees.Remove(employee);
            return RedirectToAction("Index");

        }
    }
}
