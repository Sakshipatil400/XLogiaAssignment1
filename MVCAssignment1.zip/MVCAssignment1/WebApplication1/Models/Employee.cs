﻿
    namespace WebApplication1.Models
    {
    using System.Data;
    using System.Data.SqlClient;
    using System.ComponentModel.DataAnnotations;

        public class Employee
        {
            public int Id { get; set; }

            public string Name { get; set; }

             [EmailAddress(ErrorMessage = "Invalid Email Address")]
            public string Email { get; set; }

            public int Age { get; set; }
        }
    }



