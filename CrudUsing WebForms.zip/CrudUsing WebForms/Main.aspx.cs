﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CrudUsing_WebForms
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string con = "Data Source = DESKTOP-9IA67D8\\SQLEXPRESS01 ;Initial catalog =Assignment;Integrated Security=true";
            SqlConnection db = new SqlConnection(con);
            db.Open();

            int id = Convert.ToInt32(TextBox1.Text);
            string name = TextBox2.Text;
            string Email = TextBox3.Text;
            int Age = Convert.ToInt32(TextBox4.Text);


            string insert = "insert into Employee values (" + id + ",'" + name + "','" + Email + "'," + Age + ")";
            SqlCommand cmd = new SqlCommand(insert, db);
            cmd.ExecuteNonQuery();
            db.Close();
        }

        protected void Read_Click(object sender, EventArgs e)
        {
            string con = "Data Source = DESKTOP-9IA67D8\\SQLEXPRESS01 ;Initial catalog =Assignment;Integrated Security=true";
            SqlConnection db = new SqlConnection(con);
            db.Open();

            int id = Convert.ToInt32(TextBox1.Text);

            SqlCommand cmd = new SqlCommand("select * from Employee where id=" + id, db);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                TextBox2.Text = dr.GetString(1);
                TextBox3.Text = dr.GetString(2);
                TextBox4.Text = Convert.ToString(dr.GetInt32(3));
            }
            db.Close();



        }

        protected void Update_Click(object sender, EventArgs e)
        {
            string con = "Data Source = DESKTOP-9IA67D8\\SQLEXPRESS01 ;Initial catalog =Assignment;Integrated Security=true";
            SqlConnection db = new SqlConnection(con);
            db.Open();

            int id = Convert.ToInt32(TextBox1.Text);
            string name = TextBox2.Text;
            string Email = TextBox3.Text;
            int Age = Convert.ToInt32(TextBox4.Text);

            string update = "update Employee set Name= '" + name + "' ,Email='" + Email + "', Age=" + Age + " where Id=" + id;
            SqlCommand cmd = new SqlCommand(update, db);
            cmd.ExecuteNonQuery();
            db.Close();
        }

        protected void Delete_Click(object sender, EventArgs e)
        {
            string con = "Data Source = DESKTOP-9IA67D8\\SQLEXPRESS01 ;Initial catalog =Assignment;Integrated Security=true";
            SqlConnection db = new SqlConnection(con);
            db.Open();

            int id = Convert.ToInt32(TextBox1.Text);
            String delete = "Delete from Employee where Id=" + id;
            SqlCommand cmd = new SqlCommand(delete, db);
            db.Close();
            

        }

        protected void Clear_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
        }
    }
}